const express = require('express');
const mysql = require('mysql2');

const app = express();
app.use(express.json());

// 🔹 Conexión a MySQL
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',       // tu usuario de MySQL
    password: 'Quintero.qwe*123',       // tu contraseña de MySQL
    database: 'ejerciciorobin'
});

db.connect(err => {
    if (err) {
        console.error('Error de conexión a MySQL:', err);
        return;
    }
    console.log('✅ Conectado a MySQL');
});

// 🔹 Endpoint para consultar clientes
app.get('/cliente', (req, res) => {
    db.query('SELECT * FROM cliente', (err, results) => {
        if (err) {
            res.status(500).send(err);
            return;
        }
        res.json(results);
    });
});

// 🔹 Endpoint POST para agregar un cliente
app.post('/cliente', (req, res) => {
    const { nombre, email, telefono } = req.body;

    // Validación rápida
    if (!nombre || !email || !telefono) {
        return res.status(400).json({ error: 'Todos los campos son obligatorios' });
    }

    const sql = 'INSERT INTO cliente (nombre, email, telefono) VALUES (?, ?, ?)';
    db.query(sql, [nombre, email, telefono], (err, result) => {
        if (err) {
            res.status(500).json(err);
            return;
        }
        res.json({ message: 'Cliente agregado correctamente', id: result.insertId });
    });
});

// 🔹 Endpoint para ver facturas completas
app.get('/facturas', (req, res) => {
    const sql = `
        SELECT f.id_factura, f.fecha, c.nombre AS cliente, c.email,
               m.nombre_medicamento AS medicamento, df.cantidad, p.total_linea AS pago
        FROM factura f
        JOIN cliente c ON f.id_cliente = c.id_cliente
        JOIN detalle_factura df ON f.id_factura = df.id_factura
        JOIN medicamento m ON df.id_medicamento = m.id_medicamento
        LEFT JOIN pago p ON f.id_factura = p.id_factura
        ORDER BY f.id_factura;
    `;

    db.query(sql, (err, results) => {
        if (err) {
            res.status(500).json(err);
            return;
        }
        res.json(results);
    });
});


// 🔹 Servidor escuchando
app.listen(3000, () => {
    console.log('Servidor corriendo en http://localhost:3000');
});
